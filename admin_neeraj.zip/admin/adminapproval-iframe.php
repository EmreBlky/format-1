<div style="text-align:center">
<iframe src='admin_approved.php?id=<?= $_GET["id"]?>&branch_id=<?=$_GET["branch_id"]?>&deviceModel=<?=$_GET["deviceModel"]?>&noVehicle=<?=$_GET["noVehicle"]?>' height="700" width="600" frameborder="0" scrolling="no"></iframe>
</div>