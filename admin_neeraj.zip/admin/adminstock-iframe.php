<div style="text-align:center">
<iframe src='adminstockDetails.php?id=<?= $_GET["id"]?>&branch_id=<?=$_GET["branch_id"]?>&deviceModel=<?=$_GET["deviceModel"]?>' height="500" width="800" frameborder="0" scrolling="yes"></iframe>
</div>