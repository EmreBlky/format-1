<?php

ini_set('max_execution_time', 3000);

// $servername1 = 'localhost';
// $username1 = "root";
// $password1 = "";
// $dbname1 = "inventory";

$servername1 = '203.115.101.54';
$username1 = "visiontek11000"; 
$password1 = "123456";
$dbname1 = "inventory";

 $conn1 = mysqli_connect($servername1, $username1, $password1, $dbname1);

// $servername2 = 'localhost';
// $username2 = "root";
// $password2 = "";
// $dbname2 = "internalsoftware";

$servername2 = '203.115.101.50';
$username2 = "harish123";
$password2 = "harish@123";
$dbname2 = "internalsoftware";

$conn2 = mysqli_connect($servername2, $username2, $password2, $dbname2);

if (!$conn1) {
die("Connection failed: " . mysqli_connect_error());
}

if (!$conn2) {
die("Connection failed: " . mysqli_connect_error());
}

mysqli_query($conn2, "TRUNCATE TABLE internalsoftware.admin_stock_view");


// $truncate = "truncate internalsoftware.admin_stock_view";

// $ResultTruncate = mysqli_query($conn2,$truncate);

$itemList = "select * from inventory.item_master order by parent_id";

$ResultItemList = mysqli_query($conn1,$itemList);

// echo "<pre>";print_r($ResultItemList);die;

while($row = mysqli_fetch_array($ResultItemList)) {

	//echo "<pre>";print_r($row);

 	if($row['parent_id']!=0)
 	{
 		$deviceType="select * from inventory.item_master where item_id='".$row['parent_id']."'";

 		$ResultDeviceType = mysqli_query($conn1,$deviceType);
 		//echo "<pre>";print_r($deviceType);

 		$branchList = "select * from inventory.branch_master";

 		$ResultBranchList = mysqli_query($conn1,$branchList); 		
 		
 		while($row2 = mysqli_fetch_array($ResultBranchList)){ 

 			//echo $row2['id'];

 			//echo "<pre>";print_r($row2);
 			//echo "select count(*) as new from inventory.device as d where d.active_status=1 and d.is_ffc=0 and d.is_permanent=0 and d.is_repaired=0 and d.device_status IN (62,99,116) and d.device_type='".$itemList[$i]['item_id']."' and dispatch_branch='".$branchList[$j]['id']."'";die;
 			$newCount="select count(*) as new from inventory.device as d where d.active_status=1 and d.is_ffc=0 and d.is_permanent=0 and d.is_repaired=0 and d.device_status IN (62,99,116) and d.device_type='".$row['item_id']."' and dispatch_branch='".$row2['id']."'";
			//$newCount=select_inventory_query($newCount);
				 //echo '<pre>'; print_r($newCount); die;

			$ResultNewCount = mysqli_query($conn1,$newCount);
			$row3=mysqli_fetch_array($ResultNewCount,MYSQLI_ASSOC);
			//echo $row3['new'];die;
			 //echo '<pre>'; print_r($ResultNewCount); die;
			//echo $ResultNewCount['new'];

			$ffcCount="select count(*) as ffc from inventory.device as d where d.active_status=1 and d.is_ffc=1 and d.is_permanent=1 and d.device_status IN (62,99,116) and d.device_type='".$row['item_id']."' and dispatch_branch='".$row2['id']."'";
			// $ffcCount=select_inventory_query($ffcCount);

			$ResultffcCount = mysqli_query($conn1,$ffcCount);
			$row4=mysqli_fetch_array($ResultffcCount,MYSQLI_ASSOC);
			
			// echo '<pre>'; print_r($ResultffcCount); die;
			//echo $ResultffcCount['ffc'];

			$totalDevice = $row3['new']+$row4['ffc'];
			//echo "INSERT into admin_stock_view(device_type_id,device_type,device_model,ffc_device,new_device,total_device,dispatch_branch,update_device_status) VALUES('".$row['item_id']."','".$row['parent_id']."','".$row['item_name']."','".$row3['new']."','".$row4['ffc']."','".$totalDevice."','".$row2['id']."',1)";	die;	
			$query="INSERT into admin_stock_view(device_type_id,device_type,device_model,ffc_device,new_device,total_device,dispatch_branch,update_device_status) VALUES('".$row['item_id']."','".$row['parent_id']."','".$row['item_name']."','".$row3['new']."','".$row4['ffc']."','".$totalDevice."','".$row2['id']."',1)";	
			

			$ResultQuery = mysqli_query($conn2,$query);
		}
 	}
}		

?>